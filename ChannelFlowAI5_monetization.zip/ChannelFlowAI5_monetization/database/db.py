"""
ChannelFlow AI - Database Layer
=================================

SQLite access layer for the whole project. All connections:

    * Enable ``PRAGMA foreign_keys=ON`` (SQLite defaults this OFF per
      connection, so it must be set every time or ON DELETE CASCADE
      silently does nothing).
    * Use WAL journal mode so the bot's request/response cycle and the
      forwarder's background writes don't block each other with
      "database is locked" errors.
    * Use ``sqlite3.Row`` so callers can access columns by name.

Schema
------
users                    - one row per Telegram bot user (owner of projects)
projects                 - forwarding "pipelines", owned by a user
sources                  - chats a project listens to
destinations             - Telegram chats a project forwards into
project_settings         - per-project forward/filter/delay configuration
logs                     - forward/error/retry log lines per project
stats                    - running counters per project

Added for multi-destination (Telegram + Instagram Broadcast) support:

instagram_destinations   - Instagram target(s) attached to a project
instagram_format_settings- per-project Instagram caption formatting
processing_jobs          - one row per converter-output post detected,
                           carrying it through DETECTED -> ... -> PUBLISHED
                           (or FAILED_PERMANENTLY); the unique constraint on
                           (project_id, converter_chat_id, converter_message_id)
                           is what makes duplicate publishing structurally
                           impossible, not just unlikely.
publish_logs             - append-only attempt history per processing_job
                           (processing_jobs holds current state; this holds
                           the retry history that led there)
promotional_posts        - one row per /post or /broadcast admin send
promotional_deliveries   - one row per individual target of a promotional
                           post/broadcast, so partial failures are visible

Added for Phase 7 (unified filter + formatting engine):

content_rules            - per-project ADDITIONAL filter dimensions
                           (hashtag/domain/length/sender/required-keyword
                           logic), layered on top of the existing
                           project_settings whitelist/blacklist/regex/
                           media filters rather than replacing them.
formatting_rules         - per-project content TRANSFORMATION rules
                           (prefix/suffix/replace/remove), shared by
                           every destination type - see
                           services/formatting_service.py's module
                           docstring for why this isn't duplicated per
                           platform.

Added for Phase 8 (minimal plan/entitlement layer):

users.plan               - FREE/BEGINNER/PRO/MAX, admin-assigned for
                           now (no payment processing yet). See
                           services/plan_service.py.
users.plan_expiry        - nullable; unused until Phase 14 (real
                           payments) wires up expiry enforcement, but
                           the column exists now so that phase doesn't
                           need another migration.
daily_usage               - per-project, per-day forward count, used by
                           plan_service.within_daily_forward_limit().
                           Kept separate from `stats` (a lifetime
                           counter) and from `logs` (capped/trimmed at
                           500 rows per project, so it can't reliably
                           answer "how many today").

Added for the /connect flow (per-user Telegram login):

user_telegram_sessions   - one encrypted Telethon session per customer
                           who has connected their own Telegram account
                           (core/session_crypto.py encrypts before this
                           table ever sees the session string).

Added for the referral program (Invite button):

referrals                - one row per successful invite. Captured at
                           /start (deep-link ref_<inviter_id> param),
                           rewarded later when the referred user's plan
                           actually becomes PRO - see
                           services/referral_service.py for why those
                           are two separate steps, not one.

Added for the Upgrade flow:

payment_requests          - one row per upgrade attempt: plan, price,
                           method (crypto via OXAPAY / UPI), the
                           generated payment link/reference, and the
                           admin-approval state. See
                           services/payment_service.py.
"""

import sqlite3
import os

DB_NAME = os.getenv("DB_NAME", "channelflow.db")


def get_connection():

    conn = sqlite3.connect(DB_NAME, timeout=30)

    conn.row_factory = sqlite3.Row

    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")

    return conn


def _column_exists(cur, table, column):

    cur.execute(f"PRAGMA table_info({table})")
    return any(row["name"] == column for row in cur.fetchall())


def _migrate_existing_schema(cur):
    """
    Adds columns that didn't exist in earlier versions of this project
    to tables that already exist, so upgrading in place on a database
    that already has real data never crashes with
    'no such column'.
    """

    if not _column_exists(cur, "sources", "enabled"):
        cur.execute("ALTER TABLE sources ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1")

    if not _column_exists(cur, "destinations", "enabled"):
        cur.execute("ALTER TABLE destinations ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1")

    if not _column_exists(cur, "users", "is_admin"):
        cur.execute("ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")

    # --- Phase 8: minimal plan/entitlement layer ---
    # No real payment processing yet - admin sets this manually (see
    # services/plan_service.py). Every existing user gets 'FREE' for
    # free via the column default, same backfill-for-free pattern used
    # throughout this file.
    if not _column_exists(cur, "users", "plan"):
        cur.execute("ALTER TABLE users ADD COLUMN plan TEXT NOT NULL DEFAULT 'FREE'")

    if not _column_exists(cur, "users", "plan_expiry"):
        cur.execute("ALTER TABLE users ADD COLUMN plan_expiry TIMESTAMP")

    # MAX was renamed to CREATORS - convert any rows written before the
    # rename rather than leaving them on a plan name that no longer
    # exists in plan_service.VALID_PLANS.
    cur.execute("UPDATE users SET plan='CREATORS' WHERE plan='MAX'")

    # --- Wallet + auto-renew ---
    if not _column_exists(cur, "users", "wallet_balance_usd"):
        cur.execute("ALTER TABLE users ADD COLUMN wallet_balance_usd REAL NOT NULL DEFAULT 0")

    if not _column_exists(cur, "users", "auto_renew"):
        cur.execute("ALTER TABLE users ADD COLUMN auto_renew INTEGER NOT NULL DEFAULT 0")

    # What to auto-renew INTO - set whenever a real (non-trial,
    # non-topup) plan payment is approved, read by the subscription
    # scheduler when a plan expires with auto_renew=1.
    if not _column_exists(cur, "users", "last_purchase_plan"):
        cur.execute("ALTER TABLE users ADD COLUMN last_purchase_plan TEXT")

    if not _column_exists(cur, "users", "last_purchase_months"):
        cur.execute("ALTER TABLE users ADD COLUMN last_purchase_months INTEGER")

    # --- multi-destination platform support ---
    #
    # Every existing row gets platform_type='telegram' for free because
    # that's the column default, which is exactly the "existing projects
    # default to Telegram mode" migration behaviour that's required -
    # nothing else has to run to backfill it.

    if not _column_exists(cur, "projects", "platform_type"):
        cur.execute(
            "ALTER TABLE projects ADD COLUMN platform_type TEXT NOT NULL DEFAULT 'telegram'"
        )

    if not _column_exists(cur, "projects", "promo_enabled"):
        cur.execute(
            "ALTER TABLE projects ADD COLUMN promo_enabled INTEGER NOT NULL DEFAULT 1"
        )

    # The Telegram channel that the external affiliate-converter bot
    # posts *into*. Nullable - only set on instagram_broadcast/both
    # projects. Deliberately not reusing `sources`/`destinations` for
    # this: it's not a place messages come from or get forwarded to by
    # this engine, it's the thing the processing listener watches.
    if not _column_exists(cur, "projects", "processing_chat_id"):
        cur.execute("ALTER TABLE projects ADD COLUMN processing_chat_id TEXT")

    if not _column_exists(cur, "projects", "processing_username"):
        cur.execute("ALTER TABLE projects ADD COLUMN processing_username TEXT")

    if not _column_exists(cur, "projects", "processing_title"):
        cur.execute("ALTER TABLE projects ADD COLUMN processing_title TEXT")


def init_db():

    conn = get_connection()

    cur = conn.cursor()

    # ==========================
    # USERS
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS users(
        telegram_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        is_admin INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # ==========================
    # PROJECTS
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS projects(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        status INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(telegram_id) ON DELETE CASCADE
    )
    """)

    cur.execute("CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status)")

    # ==========================
    # SOURCES
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS sources(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        chat_id TEXT NOT NULL,
        username TEXT,
        title TEXT,
        chat_type TEXT,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    cur.execute("CREATE INDEX IF NOT EXISTS idx_sources_project ON sources(project_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_sources_chat ON sources(chat_id)")

    # ==========================
    # DESTINATIONS
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS destinations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        chat_id TEXT NOT NULL,
        username TEXT,
        title TEXT,
        chat_type TEXT,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    cur.execute("CREATE INDEX IF NOT EXISTS idx_destinations_project ON destinations(project_id)")

    _migrate_existing_schema(cur)

    # ==========================
    # PROJECT SETTINGS
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS project_settings(
        project_id INTEGER PRIMARY KEY,
        mode TEXT NOT NULL DEFAULT 'forward',
        silent INTEGER NOT NULL DEFAULT 0,
        protect_content INTEGER NOT NULL DEFAULT 0,
        keep_media_groups INTEGER NOT NULL DEFAULT 1,
        delay_min REAL NOT NULL DEFAULT 0,
        delay_max REAL NOT NULL DEFAULT 0,
        media_filter TEXT NOT NULL DEFAULT 'all',
        keyword_whitelist TEXT NOT NULL DEFAULT '',
        keyword_blacklist TEXT NOT NULL DEFAULT '',
        regex_filter TEXT NOT NULL DEFAULT '',
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    # ==========================
    # LOGS
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        level TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    cur.execute("CREATE INDEX IF NOT EXISTS idx_logs_project ON logs(project_id, id DESC)")

    # ==========================
    # STATS
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS stats(
        project_id INTEGER PRIMARY KEY,
        forwarded INTEGER NOT NULL DEFAULT 0,
        failed INTEGER NOT NULL DEFAULT 0,
        retried INTEGER NOT NULL DEFAULT 0,
        filtered INTEGER NOT NULL DEFAULT 0,
        last_forward_at TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    # ==========================
    # INSTAGRAM DESTINATIONS
    # ==========================
    #
    # target_type distinguishes the two Instagram publish paths:
    #   "broadcast_channel" - no official publish API exists (verified
    #                         against current Meta docs), so these are
    #                         always routed through the Ready-to-Publish
    #                         approval queue, never auto-published.
    #   "feed"              - real Graph API container/publish flow,
    #                         actually automatable when status='available'.
    #
    # status is set by the app based on whether INSTAGRAM_ACCESS_TOKEN /
    # a valid long-lived token is actually configured and verified - it
    # is never hard-coded to "available".

    cur.execute("""
    CREATE TABLE IF NOT EXISTS instagram_destinations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        ig_user_id TEXT,
        username TEXT,
        title TEXT,
        target_type TEXT NOT NULL DEFAULT 'broadcast_channel',
        status TEXT NOT NULL DEFAULT 'setup_required',
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_instagram_destinations_project "
        "ON instagram_destinations(project_id)"
    )

    # ==========================
    # INSTAGRAM FORMAT SETTINGS
    # ==========================
    # Lazily created per project on first read, same pattern as
    # project_settings (see services/settings_service.py).

    cur.execute("""
    CREATE TABLE IF NOT EXISTS instagram_format_settings(
        project_id INTEGER PRIMARY KEY,
        prefix TEXT NOT NULL DEFAULT '',
        suffix TEXT NOT NULL DEFAULT '',
        cta TEXT NOT NULL DEFAULT '',
        hashtags TEXT NOT NULL DEFAULT '',
        emoji_enabled INTEGER NOT NULL DEFAULT 1,
        source_attribution INTEGER NOT NULL DEFAULT 0,
        link_placement TEXT NOT NULL DEFAULT 'bottom',
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    # ==========================
    # PROCESSING JOBS
    # ==========================
    # One row per message detected in a project's processing_chat_id
    # (the converter output channel). The UNIQUE constraint below is the
    # actual duplicate-publish guard, not just the status field - even
    # a crash/retry/duplicate-update mid-insert can't create a second
    # row for the same converted message.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS processing_jobs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        source_chat_id TEXT,
        source_message_id INTEGER,
        converter_chat_id TEXT NOT NULL,
        converter_message_id INTEGER NOT NULL,
        media_type TEXT,
        media_count INTEGER NOT NULL DEFAULT 0,
        text_content TEXT,
        detected_urls TEXT NOT NULL DEFAULT '[]',
        destination_id INTEGER,
        status TEXT NOT NULL DEFAULT 'DETECTED',
        attempts INTEGER NOT NULL DEFAULT 0,
        error TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        published_at TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
        FOREIGN KEY(destination_id) REFERENCES instagram_destinations(id) ON DELETE SET NULL,
        UNIQUE(project_id, converter_chat_id, converter_message_id)
    )
    """)

    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_processing_jobs_project "
        "ON processing_jobs(project_id, id DESC)"
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_processing_jobs_status "
        "ON processing_jobs(status)"
    )

    # ==========================
    # PUBLISH LOGS
    # ==========================
    # Append-only attempt history per processing_job - processing_jobs
    # holds *current* status; this holds every attempt that led there,
    # for debugging a specific post per FINAL ACCEPTANCE CRITERIA #17.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS publish_logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id INTEGER NOT NULL,
        attempt INTEGER NOT NULL,
        status TEXT NOT NULL,
        error TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(job_id) REFERENCES processing_jobs(id) ON DELETE CASCADE
    )
    """)

    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_publish_logs_job ON publish_logs(job_id)"
    )

    # ==========================
    # PROMOTIONAL POSTS / DELIVERIES
    # ==========================
    # kind distinguishes /post (one admin-picked target) from /broadcast
    # (many targets) - both share the same delivery-tracking shape.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS promotional_posts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_id INTEGER NOT NULL,
        kind TEXT NOT NULL DEFAULT 'broadcast',
        text_content TEXT,
        media_file_id TEXT,
        media_type TEXT,
        target_scope TEXT NOT NULL DEFAULT 'all',
        status TEXT NOT NULL DEFAULT 'DRAFT',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS promotional_deliveries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        promo_post_id INTEGER NOT NULL,
        project_id INTEGER,
        destination_type TEXT NOT NULL,
        destination_ref TEXT NOT NULL,
        status TEXT NOT NULL,
        error TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(promo_post_id) REFERENCES promotional_posts(id) ON DELETE CASCADE,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL
    )
    """)

    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_promo_deliveries_post "
        "ON promotional_deliveries(promo_post_id)"
    )

    # ==========================
    # REMINDER LOG (subscription scheduler dedup)
    # ==========================
    # UNIQUE(user_id, plan_expiry, days_mark) means "send the 3-day
    # reminder for THIS specific expiry once" - core/subscription_
    # scheduler.py's loop runs hourly and would otherwise resend the
    # same reminder ~24 times on the day it's due. A renewal changes
    # plan_expiry, which naturally makes the old reminder rows
    # irrelevant without needing to clean them up.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS reminder_log(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        plan_expiry TEXT NOT NULL,
        days_mark INTEGER NOT NULL,
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, plan_expiry, days_mark)
    )
    """)

    # ==========================
    # CONTENT RULES (Phase 7)
    # ==========================
    # Additional filter dimensions layered on top of
    # project_settings.{media_filter,keyword_whitelist,keyword_blacklist,
    # regex_filter} - deliberately a separate table rather than more
    # columns crammed onto project_settings, but conceptually the SAME
    # "should this message be forwarded at all" gate, checked together
    # in core/forwarder.py's _passes_all_filters(). Lazily created on
    # first read, same pattern as project_settings.
    #
    # filter_logic governs required_keywords only: "all" = every listed
    # keyword must appear, "any" = at least one must appear.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS content_rules(
        project_id INTEGER PRIMARY KEY,
        required_keywords TEXT NOT NULL DEFAULT '',
        filter_logic TEXT NOT NULL DEFAULT 'any',
        hashtag_filter TEXT NOT NULL DEFAULT '',
        domain_whitelist TEXT NOT NULL DEFAULT '',
        domain_blacklist TEXT NOT NULL DEFAULT '',
        min_length INTEGER,
        max_length INTEGER,
        sender_whitelist TEXT NOT NULL DEFAULT '',
        sender_blacklist TEXT NOT NULL DEFAULT '',
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    # ==========================
    # FORMATTING RULES (Phase 7)
    # ==========================
    # Content TRANSFORMATION (as opposed to content_rules, which only
    # decides forward-or-not). Applied in Telegram copy mode and by the
    # Instagram caption formatter - see services/formatting_service.py.
    # Never applied in Telegram forward mode: native forwards can't have
    # their content edited, and spec requires preserving native forward
    # behaviour rather than faking it.
    #
    # remove_patterns / replace_rules are stored as JSON so this table
    # doesn't need a variable number of columns for a variable number of
    # rules.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS formatting_rules(
        project_id INTEGER PRIMARY KEY,
        prefix TEXT NOT NULL DEFAULT '',
        suffix TEXT NOT NULL DEFAULT '',
        remove_patterns TEXT NOT NULL DEFAULT '[]',
        replace_rules TEXT NOT NULL DEFAULT '[]',
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    # ==========================
    # DAILY USAGE (Phase 8)
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS daily_usage(
        project_id INTEGER NOT NULL,
        usage_date TEXT NOT NULL,
        forward_count INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY(project_id, usage_date),
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """)

    # ==========================
    # USER TELEGRAM SESSIONS (per-user /connect)
    # ==========================
    # encrypted_session is ALWAYS ciphertext - see
    # core/session_crypto.py. Nothing writes plaintext here.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS user_telegram_sessions(
        telegram_id INTEGER PRIMARY KEY,
        encrypted_session TEXT NOT NULL,
        phone_number TEXT,
        status TEXT NOT NULL DEFAULT 'connected',
        connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(telegram_id) REFERENCES users(telegram_id) ON DELETE CASCADE
    )
    """)

    # ==========================
    # REFERRALS
    # ==========================
    # referred_id is UNIQUE - each person can only ever be someone's
    # referral once (whoever's link they first used), so there's no
    # ambiguity about who gets rewarded. reward_granted flips to 1 the
    # first (and only) time the referred user's plan becomes PRO -
    # see services/referral_service.py.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS referrals(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        referrer_id INTEGER NOT NULL,
        referred_id INTEGER NOT NULL UNIQUE,
        reward_granted INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        rewarded_at TIMESTAMP,
        FOREIGN KEY(referrer_id) REFERENCES users(telegram_id) ON DELETE CASCADE,
        FOREIGN KEY(referred_id) REFERENCES users(telegram_id) ON DELETE CASCADE
    )
    """)

    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id)"
    )

    # ==========================
    # PAYMENT REQUESTS (Upgrade flow)
    # ==========================

    cur.execute("""
    CREATE TABLE IF NOT EXISTS payment_requests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        plan TEXT NOT NULL,
        amount_usd REAL NOT NULL,
        method TEXT NOT NULL,
        payment_reference TEXT,
        screenshot_file_id TEXT,
        status TEXT NOT NULL DEFAULT 'PENDING_PAYMENT',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        decided_at TIMESTAMP,
        decided_by INTEGER,
        FOREIGN KEY(user_id) REFERENCES users(telegram_id) ON DELETE CASCADE
    )
    """)

    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_payment_requests_user ON payment_requests(user_id, id DESC)"
    )

    if not _column_exists(cur, "payment_requests", "purpose"):
        cur.execute("ALTER TABLE payment_requests ADD COLUMN purpose TEXT NOT NULL DEFAULT 'plan'")

    if not _column_exists(cur, "payment_requests", "months"):
        cur.execute("ALTER TABLE payment_requests ADD COLUMN months INTEGER")

    # ==========================
    # WALLET TRANSACTIONS
    # ==========================
    # Ledger, not just a running total - users.wallet_balance_usd is a
    # cached sum kept in sync by services/wallet_service.py, but every
    # credit/debit is recorded here too so a balance is always
    # auditable back to the payment_request or auto-renew event that
    # produced it.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS wallet_transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount_usd REAL NOT NULL,
        direction TEXT NOT NULL,
        reference TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(telegram_id) ON DELETE CASCADE
    )
    """)

    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_wallet_tx_user ON wallet_transactions(user_id, id DESC)"
    )

    # ==========================
    # PLAN DURATIONS (admin-configurable pricing/discounts)
    # ==========================
    # One row per (plan, months) combination that's actually for sale,
    # with its own discount_percent - admin-editable via
    # /setduration, never hard-coded in Python, so changing a discount
    # is a data change, not a deploy. See services/pricing_service.py.

    cur.execute("""
    CREATE TABLE IF NOT EXISTS plan_durations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan TEXT NOT NULL,
        months INTEGER NOT NULL,
        discount_percent REAL NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        UNIQUE(plan, months)
    )
    """)

    # Seed sensible defaults once - admin can change/add rows later via
    # /setduration without touching code. Only runs if the table is
    # empty, so it never overwrites an admin's edits on later boots.
    cur.execute("SELECT COUNT(*) FROM plan_durations")
    if cur.fetchone()[0] == 0:

        default_discounts = {1: 0, 3: 10, 6: 15, 12: 20}

        for plan in ("BEGINNER", "PRO"):
            for months, discount in default_discounts.items():
                cur.execute(
                    "INSERT INTO plan_durations(plan, months, discount_percent) VALUES (?, ?, ?)",
                    (plan, months, discount),
                )

    conn.commit()
    conn.close()
