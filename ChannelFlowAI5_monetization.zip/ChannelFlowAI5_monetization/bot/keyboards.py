from telegram import (
    ReplyKeyboardMarkup,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

import json

# ==========================================
# MAIN MENU
# ==========================================

main_menu = ReplyKeyboardMarkup(

    [

        ["➕ New Project"],

        ["📁 My Projects"],

        ["📊 Status", "⚙ Settings"],

        ["📦 My Plan"]

    ],

    resize_keyboard=True,

    is_persistent=True
)


# ==========================================
# PRE-LOGIN MENU
# ==========================================
# Shown before a user has connected their own Telegram account via
# /connect. Nothing project-related is reachable from here - see
# bot/handlers.py's start() for the gating logic.

pre_login_menu = ReplyKeyboardMarkup(

    [

        ["🚀 Connect Now"],

        ["📖 Guide", "🧭 Tour"]

    ],

    resize_keyboard=True,

    is_persistent=True

)


# ==========================================
# PROJECT KEYBOARD
# ==========================================

def project_keyboard(project_id, running=None, platform_type=None):
    """
    ``running``: True/False if the caller already knows the project's
    current status - shows just the one relevant button (Stop while
    running, Start while stopped) so there's a single obvious tap.
    Left as None (both buttons shown) for callers that don't have the
    status handy, so nothing else has to change.

    ``platform_type``: when it's "instagram_broadcast" or "both", an
    extra "📸 Instagram" row is added. Left as None (row omitted) for
    any existing caller that doesn't pass it, so this stays backward
    compatible everywhere it isn't updated.
    """

    if running is True:
        start_stop_row = [
            InlineKeyboardButton("⏹ Stop", callback_data=f"stop:{project_id}")
        ]
    elif running is False:
        start_stop_row = [
            InlineKeyboardButton("▶ Start", callback_data=f"start:{project_id}")
        ]
    else:
        start_stop_row = [
            InlineKeyboardButton("▶ Start", callback_data=f"start:{project_id}"),
            InlineKeyboardButton("⏹ Stop", callback_data=f"stop:{project_id}"),
        ]

    instagram_row = (
        [InlineKeyboardButton("📸 Instagram", callback_data=f"instagram:{project_id}")]
        if platform_type in ("instagram_broadcast", "both")
        else None
    )

    rows = [

            [

                InlineKeyboardButton(

                    "➕ Source",

                    callback_data=f"source:{project_id}"

                ),

                InlineKeyboardButton(

                    "➕ Destination",

                    callback_data=f"destination:{project_id}"

                )

            ],

            [

                InlineKeyboardButton(

                    "📥 Sources",

                    callback_data=f"listsource:{project_id}"

                ),

                InlineKeyboardButton(

                    "📤 Destinations",

                    callback_data=f"listdestination:{project_id}"

                )

            ],

            start_stop_row,

            [

                InlineKeyboardButton(
                    "🧪 Test All Destinations",
                    callback_data=f"testproject:{project_id}"
                )

            ],

            [

                InlineKeyboardButton(

                    "✏ Rename",

                    callback_data=f"rename:{project_id}"

                ),

                InlineKeyboardButton(

                    "🗑 Delete",

                    callback_data=f"delete:{project_id}"

                )

            ],

            [

                InlineKeyboardButton(
                    "⚙ Forward Settings",
                    callback_data=f"projsettings:{project_id}"
                ),

                InlineKeyboardButton(
                    "🧹 Filters",
                    callback_data=f"projfilters:{project_id}"
                )

            ],

            [

                InlineKeyboardButton(
                    "📝 Formatting",
                    callback_data=f"formatting:{project_id}"
                ),

            ],

            [

                InlineKeyboardButton(
                    "📊 Stats",
                    callback_data=f"stats:{project_id}"
                ),

                InlineKeyboardButton(
                    "📜 Logs",
                    callback_data=f"logs:{project_id}"
                )

            ]

        ]

    if instagram_row:
        rows.append(instagram_row)

    return InlineKeyboardMarkup(rows)


# ==========================================
# SOURCE ITEM KEYBOARD
# ==========================================

def source_item_keyboard(source_id, project_id, enabled=True):

    return InlineKeyboardMarkup(

        [

            [

                InlineKeyboardButton(
                    "⏸ Disable" if enabled else "▶ Enable",
                    callback_data=f"togglesource:{source_id}:{project_id}"
                ),

                InlineKeyboardButton(
                    "🗑 Delete Source",
                    callback_data=f"deletesource:{source_id}:{project_id}"
                )

            ],

            [

                InlineKeyboardButton(
                    "⬅ Back to Sources",
                    callback_data=f"listsource:{project_id}"
                )

            ]

        ]

    )


# ==========================================
# DESTINATION ITEM KEYBOARD
# ==========================================

def destination_item_keyboard(destination_id, project_id, enabled=True):

    return InlineKeyboardMarkup(

        [

            [

                InlineKeyboardButton(
                    "⏸ Disable" if enabled else "▶ Enable",
                    callback_data=f"toggledestination:{destination_id}:{project_id}"
                ),

                InlineKeyboardButton(
                    "🗑 Delete Destination",
                    callback_data=f"deletedestination:{destination_id}:{project_id}"
                )

            ],

            [

                InlineKeyboardButton(
                    "🧪 Test",
                    callback_data=f"testdestination:{destination_id}:{project_id}"
                )

            ],

            [

                InlineKeyboardButton(
                    "⬅ Back to Destinations",
                    callback_data=f"listdestination:{project_id}"
                )

            ]

        ]

    )


# ==========================================
# PROJECT FORWARD SETTINGS KEYBOARD
# ==========================================

def project_settings_keyboard(project_id, settings):

    mode = settings["mode"]
    silent = bool(settings["silent"])
    protect = bool(settings["protect_content"])
    albums = bool(settings["keep_media_groups"])

    return InlineKeyboardMarkup(

        [

            [
                InlineKeyboardButton(
                    f"Mode: {'📨 Forward' if mode == 'forward' else '📝 Copy'}",
                    callback_data=f"togglemode:{project_id}"
                )
            ],

            [
                InlineKeyboardButton(
                    f"🔕 Silent: {'On' if silent else 'Off'}",
                    callback_data=f"togglesilent:{project_id}"
                ),
                InlineKeyboardButton(
                    f"🛡 Protect Content: {'On' if protect else 'Off'}",
                    callback_data=f"toggleprotect:{project_id}"
                )
            ],

            [
                InlineKeyboardButton(
                    f"🖼 Keep Albums: {'On' if albums else 'Off'}",
                    callback_data=f"togglealbum:{project_id}"
                )
            ],

            [
                InlineKeyboardButton(
                    f"⏱ Delay: {settings['delay_min']}-{settings['delay_max']}s",
                    callback_data=f"setdelay:{project_id}"
                )
            ],

            [
                InlineKeyboardButton(
                    "⬅ Back to Project",
                    callback_data=f"backproject:{project_id}"
                )
            ]

        ]

    )


# ==========================================
# PROJECT FILTER SETTINGS KEYBOARD
# ==========================================

MEDIA_FILTER_CHOICES = (
    "all", "text", "photo", "video", "audio",
    "document", "voice", "sticker", "poll", "animation",
)


def project_filters_keyboard(project_id, settings, content_rules=None):

    rows = [

        [
            InlineKeyboardButton(
                f"🎛 Media Type: {settings['media_filter']}",
                callback_data=f"mediafilter:{project_id}"
            )
        ],

        [
            InlineKeyboardButton(
                "✅ Whitelist Keywords",
                callback_data=f"setwhitelist:{project_id}"
            )
        ],

        [
            InlineKeyboardButton(
                "🚫 Blacklist Keywords",
                callback_data=f"setblacklist:{project_id}"
            )
        ],

        [
            InlineKeyboardButton(
                "🔤 Regex Filter",
                callback_data=f"setregex:{project_id}"
            )
        ],

    ]

    # ---- Phase 7: additional content rule dimensions ----
    if content_rules is not None:

        logic = content_rules["filter_logic"]

        rows += [

            [
                InlineKeyboardButton(
                    f"🔑 Required Keywords ({logic.upper()})",
                    callback_data=f"crfield:{project_id}:required_keywords"
                ),
                InlineKeyboardButton(
                    "🔁 Toggle ALL/ANY",
                    callback_data=f"crlogic:{project_id}"
                ),
            ],

            [
                InlineKeyboardButton(
                    "#️⃣ Hashtag Filter",
                    callback_data=f"crfield:{project_id}:hashtag_filter"
                )
            ],

            [
                InlineKeyboardButton(
                    "🌐 Domain Whitelist",
                    callback_data=f"crfield:{project_id}:domain_whitelist"
                ),
                InlineKeyboardButton(
                    "🌐 Domain Blacklist",
                    callback_data=f"crfield:{project_id}:domain_blacklist"
                ),
            ],

            [
                InlineKeyboardButton(
                    "📏 Length Bounds",
                    callback_data=f"crfield:{project_id}:length"
                )
            ],

            [
                InlineKeyboardButton(
                    "👤 Sender Whitelist",
                    callback_data=f"crfield:{project_id}:sender_whitelist"
                ),
                InlineKeyboardButton(
                    "👤 Sender Blacklist",
                    callback_data=f"crfield:{project_id}:sender_blacklist"
                ),
            ],
        ]

    rows += [

        [
            InlineKeyboardButton(
                "🧹 Clear All Filters",
                callback_data=f"clearfilters:{project_id}"
            )
        ],

        [
            InlineKeyboardButton(
                "⬅ Back to Project",
                callback_data=f"backproject:{project_id}"
            )
        ]

    ]

    return InlineKeyboardMarkup(rows)


def media_filter_choice_keyboard(project_id):

    rows = []
    row = []

    for choice in MEDIA_FILTER_CHOICES:

        row.append(
            InlineKeyboardButton(
                choice,
                callback_data=f"mediafilterset:{project_id}:{choice}"
            )
        )

        if len(row) == 3:
            rows.append(row)
            row = []

    if row:
        rows.append(row)

    rows.append([
        InlineKeyboardButton(
            "⬅ Back",
            callback_data=f"projfilters:{project_id}"
        )
    ])

    return InlineKeyboardMarkup(rows)


# ==========================================
# SETTINGS KEYBOARD
# ==========================================

# ==========================================
# ACCOUNT CARD (7-button /start screen)
# ==========================================

def account_card_keyboard(connected: bool):

    connect_row = (
        [InlineKeyboardButton("✅ Connected", callback_data="acct:noop")]
        if connected
        else [InlineKeyboardButton("🚀 Connect Now", callback_data="acct:connect")]
    )

    return InlineKeyboardMarkup([
        connect_row,
        [
            InlineKeyboardButton("💎 Upgrade", callback_data="acct:upgrade"),
            InlineKeyboardButton("🎁 Invite", callback_data="acct:earn"),
        ],
        [
            InlineKeyboardButton("📖 Guide", callback_data="acct:guide"),
            InlineKeyboardButton("🧭 Tour", callback_data="acct:tour"),
        ],
        [
            InlineKeyboardButton("🌐 Language", callback_data="acct:language"),
            InlineKeyboardButton("🆘 Support", callback_data="acct:support"),
        ],
    ])


def settings_keyboard(auto_renew_enabled: bool = False):
    """Now a function (was a fixed module-level keyboard) so it can
    reflect the current Auto-Renew state - see services/wallet_service.py."""

    renew_label = "🔁 Auto-Renew: ON" if auto_renew_enabled else "🔁 Auto-Renew: OFF"

    return InlineKeyboardMarkup([

        [InlineKeyboardButton("🔄 Refresh Status", callback_data="settings:refresh")],
        [InlineKeyboardButton("💰 Wallet", callback_data="settings:wallet")],
        [InlineKeyboardButton(renew_label, callback_data="settings:togglerenew")],
        [InlineKeyboardButton("🔌 Disconnect Telegram Account", callback_data="settings:disconnect")],

    ])


# ==========================================
# ADMIN KEYBOARD
# ==========================================

admin_keyboard = InlineKeyboardMarkup(

    [

        [
            InlineKeyboardButton(
                "🔄 Refresh Dashboard",
                callback_data="admin:refresh"
            )
        ],

        [
            InlineKeyboardButton(
                "📢 Broadcast",
                callback_data="admin:broadcast"
            )
        ],

        [
            InlineKeyboardButton(
                "🛠 Toggle Maintenance Mode",
                callback_data="admin:maintenance"
            )
        ]

    ]

)

# ==========================================
# PROJECT PLATFORM SELECTION (new project flow)
# ==========================================

def platform_selection_keyboard():
    """Shown right after a new project's name is captured. Instagram
    Broadcast and Facebook Page were removed from the platform roadmap
    (platform priority migration) - Telegram -> Telegram is the only
    live choice until a verified WhatsApp Channel provider adapter
    exists (see services/platform_registry.py). The locked rows are
    shown so the roadmap is visible without being selectable, matching
    the "Coming Soon" pattern used elsewhere rather than hiding them
    entirely."""

    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📡 Telegram → Telegram", callback_data="platform:telegram")],
        [InlineKeyboardButton("🟢 Telegram → WhatsApp Channel (Coming Soon)", callback_data="platform:locked")],
        [InlineKeyboardButton("🧵 Telegram → Threads (Coming Soon)", callback_data="platform:locked")],
        [InlineKeyboardButton("📌 Telegram → Pinterest (Coming Soon)", callback_data="platform:locked")],
    ])


# ==========================================
# INSTAGRAM / PROCESSING MANAGEMENT
# ==========================================

def instagram_management_keyboard(project_id, has_processing_channel, destinations):

    buttons = []

    buttons.append([
        InlineKeyboardButton(
            "🔗 Set Converter Output Channel" if not has_processing_channel else "🔄 Change Converter Output Channel",
            callback_data=f"igsetprocessing:{project_id}",
        )
    ])

    for dest in destinations:
        label = dest["username"] or dest["ig_user_id"] or "Instagram destination"
        status_icon = "🟢" if dest["status"] == "available" else "🟡"
        buttons.append([
            InlineKeyboardButton(
                f"{status_icon} {label} ({dest['target_type']})",
                callback_data=f"igdestination:{dest['id']}",
            )
        ])

    buttons.append([
        InlineKeyboardButton("➕ Add Instagram Destination", callback_data=f"igadddest:{project_id}")
    ])

    buttons.append([
        InlineKeyboardButton("📋 Review Approval Queue", callback_data=f"igqueue:{project_id}:0")
    ])

    buttons.append([
        InlineKeyboardButton("🎨 Caption Formatting", callback_data=f"igformat:{project_id}")
    ])

    buttons.append([
        InlineKeyboardButton("⬅ Back to Project", callback_data=f"backproject:{project_id}")
    ])

    return InlineKeyboardMarkup(buttons)


def instagram_destination_type_keyboard(project_id):

    return InlineKeyboardMarkup([
        [InlineKeyboardButton(
            "📋 Broadcast Channel (approval queue)",
            callback_data=f"igtargettype:{project_id}:broadcast_channel",
        )],
        [InlineKeyboardButton(
            "📰 Regular Feed (auto-publish)",
            callback_data=f"igtargettype:{project_id}:feed",
        )],
        [InlineKeyboardButton("❌ Cancel", callback_data=f"instagram:{project_id}")],
    ])


def approval_queue_item_keyboard(job_id, project_id, offset):

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Mark Published", callback_data=f"igjobdone:{job_id}:{project_id}:{offset}"),
            InlineKeyboardButton("⏭ Skip", callback_data=f"igjobskip:{job_id}:{project_id}:{offset}"),
        ],
        [InlineKeyboardButton("⬅ Back", callback_data=f"instagram:{project_id}")],
    ])


# ==========================================
# FORMATTING (Phase 7)
# ==========================================

def formatting_keyboard(project_id, rules):

    prefix_label = f"➕ Prefix: {rules['prefix'][:20]}" if rules["prefix"] else "➕ Set Prefix"
    suffix_label = f"➖ Suffix: {rules['suffix'][:20]}" if rules["suffix"] else "➖ Set Suffix"

    replace_count = len(json.loads(rules["replace_rules"] or "[]"))
    remove_count = len(json.loads(rules["remove_patterns"] or "[]"))

    return InlineKeyboardMarkup([

        [InlineKeyboardButton(prefix_label, callback_data=f"fmtfield:{project_id}:prefix")],
        [InlineKeyboardButton(suffix_label, callback_data=f"fmtfield:{project_id}:suffix")],

        [InlineKeyboardButton(
            f"🔁 Replace Rules ({replace_count})", callback_data=f"fmtreplace:{project_id}"
        )],

        [InlineKeyboardButton(
            f"✂ Remove Patterns ({remove_count})", callback_data=f"fmtremove:{project_id}"
        )],

        [InlineKeyboardButton("🧹 Clear All Formatting", callback_data=f"fmtclear:{project_id}")],
        [InlineKeyboardButton("⬅ Back to Project", callback_data=f"backproject:{project_id}")],
    ])


def formatting_replace_list_keyboard(project_id, rules_list):

    rows = []

    for i, rule in enumerate(rules_list):
        label = f"❌ {rule['find'][:15]} → {rule['replace'][:15]}"
        rows.append([InlineKeyboardButton(label, callback_data=f"fmtreplacedel:{project_id}:{i}")])

    rows.append([InlineKeyboardButton("➕ Add Replace Rule", callback_data=f"fmtreplaceadd:{project_id}")])
    rows.append([InlineKeyboardButton("⬅ Back", callback_data=f"formatting:{project_id}")])

    return InlineKeyboardMarkup(rows)


def formatting_remove_list_keyboard(project_id, patterns):

    rows = []

    for i, pattern in enumerate(patterns):
        rows.append([InlineKeyboardButton(f"❌ {pattern[:30]}", callback_data=f"fmtremovedel:{project_id}:{i}")])

    rows.append([InlineKeyboardButton("➕ Add Remove Pattern", callback_data=f"fmtremoveadd:{project_id}")])
    rows.append([InlineKeyboardButton("⬅ Back", callback_data=f"formatting:{project_id}")])

    return InlineKeyboardMarkup(rows)
