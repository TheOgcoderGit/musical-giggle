import os
from pathlib import Path
from dotenv import load_dotenv

# load_dotenv() with no path relies on inspecting the Python call stack
# to guess where the project folder is. That guess breaks under Pydroid3
# specifically, because Pydroid3 runs scripts through its own exec()
# wrapper (iiec_run.py) rather than invoking python directly, so the
# stack frame dotenv looks at doesn't point at this file's real folder -
# .env then silently fails to load even when it's sitting right next to
# this file, and every os.getenv() below returns None. Pointing at the
# .env path explicitly (relative to this file, not the call stack or
# the current working directory) works the same everywhere: Pydroid3,
# a normal `python main.py`, a systemd service, anything.
load_dotenv(Path(__file__).resolve().parent / ".env")

BOT_TOKEN = os.getenv("BOT_TOKEN")
API_ID_RAW = os.getenv("API_ID")
API_HASH = os.getenv("API_HASH")
SESSION_NAME = os.getenv("SESSION_NAME", "ChannelFlow")

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is not set. Add it to your .env file.")

if not API_ID_RAW:
    raise RuntimeError("API_ID is not set. Add it to your .env file.")

if not API_HASH:
    raise RuntimeError("API_HASH is not set. Add it to your .env file.")

try:
    API_ID = int(API_ID_RAW)
except ValueError:
    raise RuntimeError("API_ID must be a numeric Telegram API id.")

# Comma-separated list of Telegram user ids allowed to use /admin,
# e.g. ADMIN_IDS=123456789,987654321
ADMIN_IDS = {
    int(x.strip())
    for x in os.getenv("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}

# ==========================================
# INSTAGRAM (optional)
# ==========================================
# All optional and unchecked here on purpose: a deployment with no
# Instagram project configured should never fail to start over this.
# Capability is reported to the user via
# destinations.instagram_destination.is_configured()/verify_capability(),
# not by crashing at import time.

INSTAGRAM_APP_ID = os.getenv("INSTAGRAM_APP_ID")
INSTAGRAM_APP_SECRET = os.getenv("INSTAGRAM_APP_SECRET")
INSTAGRAM_ACCESS_TOKEN = os.getenv("INSTAGRAM_ACCESS_TOKEN")

# ==========================================
# PER-USER TELEGRAM LOGIN (optional)
# ==========================================
# Required only if you enable the /connect flow (core/user_sessions.py)
# that lets customers log their own Telegram account into the bot for
# per-user forwarding. Generate with:
#   python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# Deliberately no fallback if this is unset - see
# core/session_crypto.py's module docstring for why.
SESSION_ENCRYPTION_KEY = os.getenv("SESSION_ENCRYPTION_KEY")

# OXAPAY (crypto payments) and UPI (manual, admin-approved) - Phase 14.
OXAPAY_API_KEY = os.getenv("OXAPAY_API_KEY")
UPI_ID = os.getenv("UPI_ID")
UPI_PAYEE_NAME = os.getenv("UPI_PAYEE_NAME")
