"""
Forward-engine lifecycle.

Runs as a plain ``asyncio.Task`` on the *same* event loop as the
Telegram bot (python-telegram-bot), scheduled from ``main.py``'s
``post_init`` hook.

Why this matters
-----------------
An earlier version of this file started the forward engine on a
separate OS thread, with its own ``asyncio.run(...)`` (its own event
loop). Forwarding itself worked fine there, but the shared Telethon
``client`` (``core.client.client``) got connected/authorized on that
thread's loop. Any on-demand Telethon call made from the *bot's* loop
(e.g. resolving a channel via ``get_chat`` when adding a source or
destination) was then reaching into a client bound to a different loop,
which hangs or fails silently - Telethon clients are not safe to drive
from two event loops at once. That was the "sources/destinations won't
add" bug: forwarding kept working, on-demand lookups from the bot did
not.

The fix is architectural, not a patch: there is only one event loop in
the whole process now, so there's nothing to bridge.
"""
import asyncio
import logging
from typing import Optional

from core.forwarder import start_forwarder
from core.processing_listener import start_processing_listener
from core import client_pool
from core.subscription_scheduler import run_subscription_scheduler
from bot import notifier

logger = logging.getLogger(__name__)

_forward_task: Optional[asyncio.Task] = None
_processing_task: Optional[asyncio.Task] = None
_owner_engines_task: Optional[asyncio.Task] = None
_scheduler_task: Optional[asyncio.Task] = None

_INITIAL_BACKOFF = 5
_MAX_BACKOFF = 60


async def _run_forever() -> None:
    """Async equivalent of the old thread's restart-with-backoff loop."""

    delay = _INITIAL_BACKOFF

    while True:
        try:
            await start_forwarder()
            # run_until_disconnected() returned normally (a clean,
            # intentional disconnect) - don't spin-loop restarting it.
            break
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.exception(
                "Forward engine crashed; restarting in %ss", delay
            )

            hint = (
                "The Telethon session isn't authorized. Run "
                "`python -m core.authorize` on the server once, then "
                "restart the bot."
                if isinstance(e, RuntimeError) and "not authorized" in str(e).lower()
                else str(e)
            )

            await notifier.notify_admins(
                "🔴 ChannelFlow AI\n\n"
                "The forward engine crashed and is retrying in the "
                f"background:\n{hint}\n\n"
                "No messages will forward until this is resolved.",
                throttle_key="engine_crash",
            )

            await asyncio.sleep(delay)
            delay = min(delay * 2, _MAX_BACKOFF)


async def _run_processing_listener_safe() -> None:
    """Starts the processing listener with its own error boundary, so a
    problem here (e.g. a bad processing_chat_id) can never take down the
    forward engine - they share a client but are otherwise independent."""

    try:
        await start_processing_listener()
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception(
            "Processing listener (converter-output -> Instagram queue) "
            "failed to start; Telegram forwarding is unaffected."
        )


async def _start_owner_engines_safe() -> None:
    """Brings back a dedicated client for every user who connected
    their own Telegram account (core/user_sessions.py) before this
    boot. Runs once (unlike the two loops above) - start_owner_engine
    connects and registers handlers but doesn't block, so there's
    nothing to keep looping on here; future connects are started
    directly from bot/handlers.py's connect success path. Its own
    error boundary for the same reason as the processing listener: a
    bad session for one owner must never take down the shared engine
    or any other owner's client."""

    try:
        await client_pool.start_all_connected_owners()
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception(
            "Failed to start one or more per-owner forwarding clients; "
            "the shared engine and unaffected owners continue normally."
        )


async def _run_subscription_scheduler_safe(bot) -> None:
    """Same error-boundary pattern as the processing listener and
    owner-engines startup - a scheduler problem must never take down
    Telegram forwarding."""

    try:
        await run_subscription_scheduler(bot)
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception(
            "Subscription scheduler crashed; forwarding is unaffected, but "
            "expiry reminders/auto-renew/downgrades have stopped running."
        )


def start_listener(bot=None) -> None:
    """
    Schedules the forward engine as a background task on the CURRENT
    event loop. Must be called from within a running event loop (see
    ``main.py``'s ``post_init`` hook) so it shares that loop with
    everything else, including the bot handlers.

    ``bot``: passed through to the subscription scheduler so it can DM
    users about expiry/renewal/downgrade events. Optional only so this
    function's existing callers (and any test harness) don't break -
    the scheduler simply doesn't start without one.
    """

    global _forward_task, _processing_task, _owner_engines_task, _scheduler_task

    if _forward_task is not None and not _forward_task.done():
        logger.info("Forward Engine Already Running")
        return

    _forward_task = asyncio.create_task(_run_forever())
    _processing_task = asyncio.create_task(_run_processing_listener_safe())
    _owner_engines_task = asyncio.create_task(_start_owner_engines_safe())

    if bot is not None:
        _scheduler_task = asyncio.create_task(_run_subscription_scheduler_safe(bot))

    logger.info("==============================")
    logger.info("Listener Started")
    logger.info("==============================")


async def stop_listener() -> None:
    """Cancels the forward engine task cleanly (used on shutdown)."""

    global _forward_task, _processing_task, _owner_engines_task, _scheduler_task

    if _scheduler_task is not None:
        _scheduler_task.cancel()
        try:
            await _scheduler_task
        except (asyncio.CancelledError, Exception):
            pass
        _scheduler_task = None

    if _processing_task is not None:
        _processing_task.cancel()
        try:
            await _processing_task
        except (asyncio.CancelledError, Exception):
            pass
        _processing_task = None

    if _owner_engines_task is not None:
        _owner_engines_task.cancel()
        try:
            await _owner_engines_task
        except (asyncio.CancelledError, Exception):
            pass
        _owner_engines_task = None

    try:
        await client_pool.stop_all_engines()
    except Exception:
        logger.exception("Error stopping per-owner forwarding clients")

    if _forward_task is None:
        return

    _forward_task.cancel()

    try:
        await _forward_task
    except (asyncio.CancelledError, Exception):
        pass

    _forward_task = None


def is_running() -> bool:
    return _forward_task is not None and not _forward_task.done()
