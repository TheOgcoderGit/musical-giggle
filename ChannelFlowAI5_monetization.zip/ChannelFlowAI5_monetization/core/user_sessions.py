"""
ChannelFlow AI - Per-User Telegram Login (/connect)
======================================================

Lets a customer log their own Telegram account into the bot, so their
projects can eventually forward using their own account rather than
the service-operator's shared session (core/client.py). This is
SEPARATE infrastructure from core/client.py/core/authorize.py on
purpose - see core/authorize.py's module docstring for why phone/OTP/
2FA collection through bot chat was originally kept out of the chat UI,
and bot/handlers.py's connect-flow messaging for the consent/safety
copy shown to the user before they type anything.

Flow
----
1. start_connect(user_id, phone_number) - opens a temporary Telethon
   client bound to a StringSession (never touches disk on its own),
   requests an OTP, and holds the client in memory keyed by user_id
   while waiting for the code.
2. submit_code(user_id, code) - completes sign-in, or raises
   NeedsPassword if the account has 2FA enabled.
3. submit_password(user_id, password) - completes 2FA sign-in.
4. On success in either step: the resulting session string is
   encrypted (core/session_crypto.py) and upserted into
   user_telegram_sessions. The temporary client disconnects
   immediately after - nothing about this module keeps a live
   connection open per connected user; that's a separate concern for
   whatever eventually runs per-user forwarding.

Safety
------
* Every pending attempt expires after PENDING_TTL_SECONDS and is
  disconnected + dropped - a user who starts /connect and never
  finishes can't leave a dangling authenticated-but-unclaimed client
  sitting in memory indefinitely.
* MAX_ATTEMPTS caps wrong-code/wrong-password tries per pending attempt
  before it's dropped and the user has to restart with /connect.
* Nothing in this module logs a phone number, code, password, or
  session string - only user ids and outcome (success/failure/reason).
"""

import asyncio
import logging
import time

from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    PhoneNumberInvalidError,
    PasswordHashInvalidError,
    FloodWaitError,
)

from config import API_ID, API_HASH
from database.db import get_connection
from core.session_crypto import encrypt_session

logger = logging.getLogger(__name__)

PENDING_TTL_SECONDS = 600  # 10 minutes to finish a /connect attempt
MAX_ATTEMPTS = 3

# user_id -> {"client": TelegramClient, "phone": str, "phone_code_hash": str,
#             "stage": "code"|"password", "attempts": int, "started_at": float}
_pending = {}
_pending_lock = asyncio.Lock()


class ConnectError(Exception):
    """User-facing failure - message is safe to show as-is."""


class NeedsPassword(Exception):
    """Sign-in succeeded on the code but this account has 2FA enabled."""


async def _drop_pending(user_id):

    state = _pending.pop(user_id, None)

    if state is not None:
        try:
            await state["client"].disconnect()
        except Exception:
            pass


async def _sweep_expired():

    now = time.monotonic()
    expired = [
        uid for uid, s in _pending.items()
        if now - s["started_at"] > PENDING_TTL_SECONDS
    ]

    for uid in expired:
        await _drop_pending(uid)


async def start_connect(user_id: int, phone_number: str):
    """Sends the OTP. Raises ConnectError with a user-safe message on
    any failure (invalid number, flood wait, etc.)."""

    async with _pending_lock:

        await _sweep_expired()
        await _drop_pending(user_id)  # restart cleanly if one was already in progress

        client = TelegramClient(StringSession(), API_ID, API_HASH)

        try:
            await client.connect()
            sent = await client.send_code_request(phone_number)

        except PhoneNumberInvalidError:
            await client.disconnect()
            raise ConnectError("That phone number doesn't look valid. Include the country code, e.g. +919876543210.")

        except FloodWaitError as e:
            await client.disconnect()
            raise ConnectError(f"Telegram asked us to wait {e.seconds}s before trying again. Please retry shortly.")

        except Exception:
            await client.disconnect()
            logger.exception("start_connect failed for user %s", user_id)
            raise ConnectError("Couldn't start the login. Please try again in a moment.")

        _pending[user_id] = {
            "client": client,
            "phone": phone_number,
            "phone_code_hash": sent.phone_code_hash,
            "stage": "code",
            "attempts": 0,
            "started_at": time.monotonic(),
        }


async def submit_code(user_id: int, code: str):
    """Returns True on full success. Raises NeedsPassword if 2FA is
    required (call submit_password next), or ConnectError on any other
    failure - the caller should let the user retry within MAX_ATTEMPTS."""

    state = _pending.get(user_id)

    if state is None or state["stage"] != "code":
        raise ConnectError("No login in progress. Send /connect <phone_number> to start.")

    client = state["client"]

    try:
        await client.sign_in(
            phone=state["phone"], code=code, phone_code_hash=state["phone_code_hash"]
        )

    except SessionPasswordNeededError:
        state["stage"] = "password"
        raise NeedsPassword()

    except (PhoneCodeInvalidError, PhoneCodeExpiredError):

        state["attempts"] += 1

        if state["attempts"] >= MAX_ATTEMPTS:
            await _drop_pending(user_id)
            raise ConnectError("Too many incorrect attempts. Send /connect <phone_number> to start over.")

        raise ConnectError("That code was incorrect or expired. Try again.")

    except Exception:
        await _drop_pending(user_id)
        logger.exception("submit_code failed for user %s", user_id)
        raise ConnectError("Something went wrong during login. Send /connect <phone_number> to start over.")

    await _finalize(user_id)
    return True


async def submit_password(user_id: int, password: str):

    state = _pending.get(user_id)

    if state is None or state["stage"] != "password":
        raise ConnectError("No login in progress. Send /connect <phone_number> to start.")

    client = state["client"]

    try:
        await client.sign_in(password=password)

    except PasswordHashInvalidError:

        state["attempts"] += 1

        if state["attempts"] >= MAX_ATTEMPTS:
            await _drop_pending(user_id)
            raise ConnectError("Too many incorrect attempts. Send /connect <phone_number> to start over.")

        raise ConnectError("Incorrect password. Try again.")

    except Exception:
        await _drop_pending(user_id)
        logger.exception("submit_password failed for user %s", user_id)
        raise ConnectError("Something went wrong during login. Send /connect <phone_number> to start over.")

    await _finalize(user_id)
    return True


async def _finalize(user_id):

    state = _pending.pop(user_id)
    client = state["client"]

    session_string = client.session.save()
    phone_number = state["phone"]

    await client.disconnect()

    encrypted = encrypt_session(session_string)

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO user_telegram_sessions(telegram_id, encrypted_session, phone_number, status)
        VALUES (?, ?, ?, 'connected')
        ON CONFLICT(telegram_id) DO UPDATE SET
            encrypted_session=excluded.encrypted_session,
            phone_number=excluded.phone_number,
            status='connected',
            connected_at=CURRENT_TIMESTAMP
        """,
        (user_id, encrypted, phone_number),
    )

    conn.commit()
    conn.close()

    logger.info("User %s connected their Telegram account", user_id)


def cancel_connect(user_id):
    """Sync-safe best-effort cancel for /cancel - actual disconnect
    happens via the async _drop_pending on next opportunity, but
    removing the dict entry immediately stops it being usable."""

    _pending.pop(user_id, None)


def is_connected(telegram_id) -> bool:

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT 1 FROM user_telegram_sessions WHERE telegram_id=? AND status='connected'",
        (telegram_id,),
    )
    row = cur.fetchone()
    conn.close()

    return row is not None


def disconnect_user(telegram_id):
    """User-initiated revoke - deletes the stored session outright
    rather than just flipping a status flag, so there's nothing left to
    leak even if the row were somehow read elsewhere."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("DELETE FROM user_telegram_sessions WHERE telegram_id=?", (telegram_id,))

    conn.commit()
    conn.close()
