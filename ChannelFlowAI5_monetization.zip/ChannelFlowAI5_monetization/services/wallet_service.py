"""
ChannelFlow AI - Wallet Service
===================================

A prepaid balance (users.wallet_balance_usd), funded through the exact
same pay -> screenshot -> admin approve/reject flow as a plan purchase
(services/payment_service.py, purpose='wallet_topup'), and spent
automatically by the subscription scheduler (core/subscription_
scheduler.py) when a user has auto_renew=1 and their plan expires.

users.wallet_balance_usd is a cached running total, kept in sync with
wallet_transactions (the actual ledger) inside credit()/debit() - every
change to the balance goes through one of these two functions so the
two can never drift apart. Never mutate users.wallet_balance_usd
directly anywhere else.
"""

from database.db import get_connection


def get_balance(user_id) -> float:

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT wallet_balance_usd FROM users WHERE telegram_id=?", (user_id,))
    row = cur.fetchone()

    conn.close()

    return row["wallet_balance_usd"] if row else 0.0


def credit(user_id, amount_usd, reference=None):

    if amount_usd <= 0:
        raise ValueError("Credit amount must be positive")

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE users SET wallet_balance_usd = wallet_balance_usd + ? WHERE telegram_id=?",
        (amount_usd, user_id),
    )

    cur.execute(
        "INSERT INTO wallet_transactions(user_id, amount_usd, direction, reference) VALUES (?, ?, 'CREDIT', ?)",
        (user_id, amount_usd, reference),
    )

    conn.commit()
    conn.close()

    return get_balance(user_id)


def debit(user_id, amount_usd, reference=None) -> bool:
    """Returns False (and changes nothing) if the balance would go
    negative - callers (the auto-renew scheduler) treat that as
    "renewal failed", never as an implicit negative-balance loan."""

    if amount_usd <= 0:
        raise ValueError("Debit amount must be positive")

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT wallet_balance_usd FROM users WHERE telegram_id=?", (user_id,))
    row = cur.fetchone()

    if row is None or row["wallet_balance_usd"] < amount_usd:
        conn.close()
        return False

    cur.execute(
        "UPDATE users SET wallet_balance_usd = wallet_balance_usd - ? WHERE telegram_id=?",
        (amount_usd, user_id),
    )

    cur.execute(
        "INSERT INTO wallet_transactions(user_id, amount_usd, direction, reference) VALUES (?, ?, 'DEBIT', ?)",
        (user_id, amount_usd, reference),
    )

    conn.commit()
    conn.close()

    return True


def get_transactions(user_id, limit=20):

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT ?",
        (user_id, limit),
    )
    rows = cur.fetchall()

    conn.close()

    return rows


def set_auto_renew(user_id, enabled: bool):

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE users SET auto_renew=? WHERE telegram_id=?",
        (1 if enabled else 0, user_id),
    )

    conn.commit()
    conn.close()


def is_auto_renew_enabled(user_id) -> bool:

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT auto_renew FROM users WHERE telegram_id=?", (user_id,))
    row = cur.fetchone()

    conn.close()

    return bool(row and row["auto_renew"])
