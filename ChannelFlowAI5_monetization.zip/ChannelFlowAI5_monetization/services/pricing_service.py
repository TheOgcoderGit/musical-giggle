"""
ChannelFlow AI - Pricing Service
====================================

Base monthly prices (services/payment_service.PLAN_PRICES, USD) times
a duration, minus a discount that's stored in the database
(plan_durations table) rather than hard-coded - an admin changing a
discount percentage is a data change via /setduration, never a code
deploy. Changing a discount only affects NEW purchases; an
already-approved payment_requests row keeps the price it was created
with, since that's a historical fact, not a live lookup.

The discount applies uniformly to both USD (crypto) and INR (UPI) -
one number, not two parallel discount schedules to keep in sync.
INR is rounded to the nearest 10 for a clean displayed price; USD is
rounded to 2 decimals.
"""

from database.db import get_connection
from services import payment_service

INR_PER_USD = 85  # approximate conversion rate - update as needed


def get_duration_options(plan):
    """Every active (plan, months) row, cheapest-first by months."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT * FROM plan_durations WHERE plan=? AND active=1 ORDER BY months ASC",
        (plan,),
    )
    rows = cur.fetchall()

    conn.close()

    return rows


def calculate_price(plan, months, discount_percent):
    """Returns a dict with both currencies, the pre-discount reference
    price (for showing "was $X"), and the effective per-month price -
    the "12 months: ₹2872 (₹3588) - save 20%, ₹239/mo" style display
    the admin asked for."""

    base_monthly_usd = payment_service.PLAN_PRICES[plan]

    full_usd = base_monthly_usd * months
    discounted_usd = round(full_usd * (1 - discount_percent / 100), 2)

    full_inr = full_usd * INR_PER_USD
    discounted_inr = discounted_usd * INR_PER_USD
    discounted_inr_rounded = round(discounted_inr / 10) * 10

    return {
        "plan": plan,
        "months": months,
        "discount_percent": discount_percent,
        "full_price_usd": round(full_usd, 2),
        "price_usd": discounted_usd,
        "full_price_inr": round(full_inr),
        "price_inr": discounted_inr_rounded,
        "effective_monthly_inr": round(discounted_inr_rounded / months),
        "effective_monthly_usd": round(discounted_usd / months, 2),
    }


def format_duration_label(pricing: dict) -> str:

    if pricing["discount_percent"] > 0:
        return (
            f"{pricing['months']} mo - ₹{pricing['price_inr']:.0f} "
            f"(₹{pricing['full_price_inr']:.0f}) - save {pricing['discount_percent']:.0f}%"
        )

    return f"{pricing['months']} mo - ₹{pricing['price_inr']:.0f}"


def set_duration(plan, months, discount_percent, active=True):
    """Admin-only, called from /setduration. Upserts by (plan, months)
    per the UNIQUE constraint on plan_durations."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO plan_durations(plan, months, discount_percent, active)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(plan, months) DO UPDATE SET
            discount_percent=excluded.discount_percent,
            active=excluded.active
        """,
        (plan, months, discount_percent, 1 if active else 0),
    )

    conn.commit()
    conn.close()
