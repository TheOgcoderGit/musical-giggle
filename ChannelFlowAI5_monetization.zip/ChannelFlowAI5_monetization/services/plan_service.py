"""
ChannelFlow AI - Plan / Entitlement Service
==============================================

Minimal plan layer: a `plan` column on `users` (FREE/BEGINNER/PRO/MAX),
admin-assigned for now since there's no payment processing yet (that's
Phase 14). This exists to unblock two things that depend on "what plan
is this user on" without waiting for full billing:

    * requires_attribution() - Phase 9's free-plan watermark system
      reads this to decide whether to append the attribution footer.
    * Usage limits (max projects / sources / destinations per project,
      daily forward cap) - enforced at creation time in bot/handlers.py
      with a clear "upgrade to do this" message, not a silent failure.

PLAN_LIMITS is the single source of truth for what each plan allows.
Nothing else should hard-code a limit number - look it up here, same
principle as services/platform_registry.py for platform metadata.
"""

from datetime import datetime, timedelta, timezone

from database.db import get_connection

VALID_PLANS = ("FREE", "BEGINNER", "PRO", "CREATORS")

TRIAL_PLAN = "CREATORS"
TRIAL_DAYS = 7

PLAN_LIMITS = {
    "FREE": {
        "max_projects": 1,
        "max_sources_per_project": 2,
        "max_destinations_per_project": 1,
        "daily_forward_limit": 100,
        "requires_attribution": True,
    },
    "BEGINNER": {
        "max_projects": 3,
        "max_sources_per_project": 5,
        "max_destinations_per_project": 3,
        "daily_forward_limit": 1000,
        "requires_attribution": False,
    },
    "PRO": {
        "max_projects": 10,
        "max_sources_per_project": 20,
        "max_destinations_per_project": 10,
        "daily_forward_limit": 10000,
        "requires_attribution": False,
    },
    "CREATORS": {
        "max_projects": 20,
        "max_sources_per_project": 20,
        "max_destinations_per_project": 10,
        "daily_forward_limit": 50000,
        "requires_attribution": False,
    },
}


def get_user_plan(telegram_id) -> str:
    """Returns the effective plan - if plan_expiry has passed, the user
    is treated as FREE regardless of the stored plan column, rather
    than silently keeping paid entitlements after expiry (Phase 14 will
    be what actually sets/clears plan_expiry; this function just
    respects it once it exists)."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT plan, plan_expiry FROM users WHERE telegram_id=?", (telegram_id,)
    )
    row = cur.fetchone()
    conn.close()

    if row is None:
        return "FREE"

    if row["plan_expiry"]:
        try:
            expiry = datetime.fromisoformat(row["plan_expiry"])
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) > expiry:
                return "FREE"
        except (TypeError, ValueError):
            pass

    return row["plan"] or "FREE"


def set_user_plan(telegram_id, plan, expiry=None):

    if plan not in VALID_PLANS:
        raise ValueError(f"Invalid plan: {plan}")

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE users SET plan=?, plan_expiry=? WHERE telegram_id=?",
        (plan, expiry, telegram_id),
    )

    conn.commit()
    conn.close()


_PLAN_RANK = {"FREE": 0, "BEGINNER": 1, "PRO": 2, "CREATORS": 3}


def extend_plan(telegram_id, minimum_plan, days):
    """Adds `days` on top of whatever plan_expiry this user currently
    has (rather than overwriting it), and raises their plan to at
    least `minimum_plan` if they're currently on something lower -
    never downgrades someone who's already on a better plan. Used by
    services/referral_service.py so stacked rewards actually stack
    instead of the last one clobbering the others."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT plan, plan_expiry FROM users WHERE telegram_id=?", (telegram_id,))
    row = cur.fetchone()

    if row is None:
        conn.close()
        return

    current_plan = row["plan"] or "FREE"
    base = datetime.now(timezone.utc)

    if row["plan_expiry"]:
        try:
            existing_expiry = datetime.fromisoformat(row["plan_expiry"])
            if existing_expiry.tzinfo is None:
                existing_expiry = existing_expiry.replace(tzinfo=timezone.utc)
            if existing_expiry > base:
                base = existing_expiry
        except (TypeError, ValueError):
            pass

    new_expiry = (base + timedelta(days=days)).isoformat()

    new_plan = (
        minimum_plan
        if _PLAN_RANK.get(minimum_plan, 0) > _PLAN_RANK.get(current_plan, 0)
        else current_plan
    )

    cur.execute(
        "UPDATE users SET plan=?, plan_expiry=? WHERE telegram_id=?",
        (new_plan, new_expiry, telegram_id),
    )

    conn.commit()
    conn.close()


def start_trial(telegram_id):
    """Grants the CREATORS trial to a brand-new user. Called once, from
    registration (database.models.register_user's caller in
    bot/handlers.py), guarded so it only ever fires for a user who has
    never had a plan set - re-running /start doesn't re-grant the
    trial, and it never overwrites an admin-assigned or paid plan."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT plan, plan_expiry FROM users WHERE telegram_id=?", (telegram_id,))
    row = cur.fetchone()

    if row is None or row["plan"] != "FREE" or row["plan_expiry"] is not None:
        # Not a brand-new FREE-with-no-history user - already on some
        # plan (trial already used, or admin/paid already applied).
        conn.close()
        return False

    expiry = (datetime.now(timezone.utc) + timedelta(days=TRIAL_DAYS)).isoformat()

    cur.execute(
        "UPDATE users SET plan=?, plan_expiry=? WHERE telegram_id=?",
        (TRIAL_PLAN, expiry, telegram_id),
    )

    conn.commit()
    conn.close()

    return True


def get_entitlements(telegram_id) -> dict:
    plan = get_user_plan(telegram_id)
    return {**PLAN_LIMITS[plan], "plan": plan}


def requires_attribution(telegram_id) -> bool:
    """The single, centralized answer to "does this user's content need
    the attribution footer" - Phase 9 calls this and only this, so the
    rule is never duplicated per route (Telegram copy mode, Instagram,
    /post, /broadcast all ask the same function)."""

    return get_entitlements(telegram_id)["requires_attribution"]


# ==========================================
# LIMIT CHECKS
# ==========================================
# Each returns (allowed: bool, reason: str|None) so callers can show
# the reason directly rather than a generic "blocked" message.

def can_create_project(telegram_id) -> tuple:

    limits = get_entitlements(telegram_id)
    max_projects = limits["max_projects"]

    if max_projects is None:
        return True, None

    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM projects WHERE user_id=?", (telegram_id,))
    current = cur.fetchone()[0]
    conn.close()

    if current >= max_projects:
        return False, (
            f"Your {limits['plan']} plan allows up to {max_projects} project(s). "
            "Upgrade to create more."
        )

    return True, None


def can_add_source(telegram_id, project_id) -> tuple:

    limits = get_entitlements(telegram_id)
    max_sources = limits["max_sources_per_project"]

    if max_sources is None:
        return True, None

    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM sources WHERE project_id=?", (project_id,))
    current = cur.fetchone()[0]
    conn.close()

    if current >= max_sources:
        return False, (
            f"Your {limits['plan']} plan allows up to {max_sources} source(s) "
            "per project. Upgrade to add more."
        )

    return True, None


def can_add_destination(telegram_id, project_id) -> tuple:

    limits = get_entitlements(telegram_id)
    max_destinations = limits["max_destinations_per_project"]

    if max_destinations is None:
        return True, None

    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM destinations WHERE project_id=?", (project_id,))
    current = cur.fetchone()[0]
    conn.close()

    if current >= max_destinations:
        return False, (
            f"Your {limits['plan']} plan allows up to {max_destinations} "
            "destination(s) per project. Upgrade to add more."
        )

    return True, None


def within_daily_forward_limit(telegram_id, project_id) -> bool:
    """Backed by daily_usage (bumped in services/stats_service.increment()
    alongside the lifetime 'forwarded' counter) rather than `logs`, which
    is capped/trimmed at 500 rows per project and so can't reliably
    answer "how many today" once a project is at all active."""

    limits = get_entitlements(telegram_id)
    daily_limit = limits["daily_forward_limit"]

    if daily_limit is None:
        return True

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT forward_count FROM daily_usage WHERE project_id=? AND usage_date=date('now')",
        (project_id,),
    )
    row = cur.fetchone()
    conn.close()

    today_count = row["forward_count"] if row else 0

    return today_count < daily_limit
