"""
ChannelFlow AI - Payment / Upgrade Service
==============================================

Flow: pick a plan -> pick a method (crypto via OXAPAY, or UPI for
India) -> get a payment reference (a real OXAPAY invoice link, or
static UPI details) with Verify/Cancel already showing -> tap Verify
-> submit a screenshot -> an admin reviews and approves or rejects.

Nothing here auto-confirms a payment. Both methods end at a human
admin tapping Approve - there's no webhook/auto-verification wired up
even for OXAPAY (it supports one; this build doesn't call it), because
"no fake success" applies to money the same as it applies to
publishing: the plan only changes when someone actually checked.

PLAN_PRICES are placeholders - see the module-level comment. Update
them before taking real payments.
"""

import logging

import httpx

from config import OXAPAY_API_KEY, UPI_ID, UPI_PAYEE_NAME
from database.db import get_connection
from services import plan_service, referral_service

logger = logging.getLogger(__name__)

# PLACEHOLDER PRICES - edit these before accepting real payments. Only
# paid plans are purchasable here; FREE needs no payment and CREATORS
# is trial-only (not sold) unless you decide otherwise later.
PLAN_PRICES = {
    "BEGINNER": 4.99,
    "PRO": 9.99,
}

OXAPAY_CREATE_INVOICE_URL = "https://api.oxapay.com/merchants/request"


def is_oxapay_configured() -> bool:
    return bool(OXAPAY_API_KEY)


def is_upi_configured() -> bool:
    return bool(UPI_ID)


async def create_oxapay_invoice(amount_usd: float, order_id: str):
    """Real OXAPAY merchant API call - verify against OXAPAY's current
    docs before relying on this in production, since API shapes do
    change. Returns (pay_link, track_id) or raises RuntimeError with a
    user-safe message."""

    if not is_oxapay_configured():
        raise RuntimeError("Crypto payment isn't configured yet - contact the admin.")

    try:
        async with httpx.AsyncClient(timeout=20) as http:

            resp = await http.post(
                OXAPAY_CREATE_INVOICE_URL,
                json={
                    "merchant": OXAPAY_API_KEY,
                    "amount": amount_usd,
                    "currency": "USD",
                    "lifeTime": 60,
                    "orderId": order_id,
                    "description": "ChannelFlow AI subscription",
                },
            )

        data = resp.json()

        if data.get("result") != 100:
            logger.error("OXAPAY invoice creation failed: %s", data)
            raise RuntimeError("Couldn't create a payment link right now. Try again shortly.")

        return data.get("payLink"), data.get("trackId")

    except httpx.HTTPError as e:
        logger.exception("OXAPAY network error")
        raise RuntimeError(f"Network error reaching the payment provider: {e}")


def create_payment_request(user_id, plan, method, payment_reference=None, months=1):
    """`plan` here is the target plan being purchased/renewed, priced
    via services/pricing_service.py for the given duration."""

    if plan not in PLAN_PRICES:
        raise ValueError(f"{plan} is not a purchasable plan")

    from services import pricing_service

    duration_options = {row["months"]: row["discount_percent"] for row in pricing_service.get_duration_options(plan)}
    discount = duration_options.get(months, 0)

    pricing = pricing_service.calculate_price(plan, months, discount)
    amount = pricing["price_usd"]

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO payment_requests(user_id, plan, amount_usd, method, payment_reference, status, purpose, months)
        VALUES (?, ?, ?, ?, ?, 'PENDING_PAYMENT', 'plan', ?)
        """,
        (user_id, plan, amount, method, payment_reference, months),
    )

    conn.commit()
    request_id = cur.lastrowid
    conn.close()

    return request_id


def create_wallet_topup_request(user_id, amount_usd, method, payment_reference=None):
    """Same lifecycle as a plan purchase (PENDING_PAYMENT -> SUBMITTED
    -> admin approves/rejects), but purpose='wallet_topup' routes the
    approval to wallet_service.credit() instead of plan_service.
    set_user_plan() - see approve_payment()."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO payment_requests(user_id, plan, amount_usd, method, payment_reference, status, purpose)
        VALUES (?, NULL, ?, ?, ?, 'PENDING_PAYMENT', 'wallet_topup')
        """,
        (user_id, amount_usd, method, payment_reference),
    )

    conn.commit()
    request_id = cur.lastrowid
    conn.close()

    return request_id


def get_payment_request(request_id):

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM payment_requests WHERE id=?", (request_id,))
    row = cur.fetchone()

    conn.close()

    return row


def submit_screenshot(request_id, file_id):

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE payment_requests SET screenshot_file_id=?, status='SUBMITTED' WHERE id=? AND status='PENDING_PAYMENT'",
        (file_id, request_id),
    )

    conn.commit()
    updated = cur.rowcount > 0
    conn.close()

    return updated


def cancel_payment_request(request_id):

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE payment_requests SET status='CANCELLED' WHERE id=? AND status IN ('PENDING_PAYMENT','SUBMITTED')",
        (request_id,),
    )

    conn.commit()
    conn.close()


def approve_payment(request_id, admin_id):
    """Branches on purpose:
        * 'plan' - sets the plan for `months` (from the request,
          priced at creation time - see create_payment_request), sets
          last_purchase_plan/months for the auto-renew scheduler
          (core/subscription_scheduler.py) to know what to renew into,
          and checks for a pending referral reward.
        * 'wallet_topup' - credits the wallet instead (services/
          wallet_service.py) - no plan change, no referral check
          (topping up isn't "taking a paid plan").

    Returns the payment_requests row (post-update) or None if it
    wasn't in a state that could be approved."""

    request = get_payment_request(request_id)

    if request is None or request["status"] != "SUBMITTED":
        return None

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE payment_requests SET status='APPROVED', decided_at=CURRENT_TIMESTAMP, decided_by=? WHERE id=?",
        (admin_id, request_id),
    )

    conn.commit()
    conn.close()

    if request["purpose"] == "wallet_topup":

        from services import wallet_service
        wallet_service.credit(request["user_id"], request["amount_usd"], reference=f"payment_request:{request_id}")

    else:

        from datetime import datetime, timedelta, timezone

        months = request["months"] or 1
        expiry = (datetime.now(timezone.utc) + timedelta(days=30 * months)).isoformat()

        plan_service.set_user_plan(request["user_id"], request["plan"], expiry=expiry)

        conn2 = get_connection()
        cur2 = conn2.cursor()
        cur2.execute(
            "UPDATE users SET last_purchase_plan=?, last_purchase_months=? WHERE telegram_id=?",
            (request["plan"], months, request["user_id"]),
        )
        conn2.commit()
        conn2.close()

        referral_service.grant_reward_if_pending(request["user_id"], request["plan"])

    return get_payment_request(request_id)


def reject_payment(request_id, admin_id):

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE payment_requests SET status='REJECTED', decided_at=CURRENT_TIMESTAMP, decided_by=? WHERE id=? AND status='SUBMITTED'",
        (admin_id, request_id),
    )

    conn.commit()
    updated = cur.rowcount > 0
    conn.close()

    return updated


STALE_HOURS = 48


def expire_stale_requests():
    """Auto-expires any request sitting in PENDING_PAYMENT or SUBMITTED
    for longer than STALE_HOURS, so a request an admin never reviewed
    doesn't stay "active" forever. Called from
    core/subscription_scheduler.py's periodic loop. Returns the list of
    expired rows (already updated) so the caller can notify each user."""

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        """
        SELECT * FROM payment_requests
        WHERE status IN ('PENDING_PAYMENT', 'SUBMITTED')
          AND created_at <= datetime('now', ?)
        """,
        (f"-{STALE_HOURS} hours",),
    )
    stale = cur.fetchall()

    if stale:
        cur.execute(
            """
            UPDATE payment_requests SET status='EXPIRED'
            WHERE status IN ('PENDING_PAYMENT', 'SUBMITTED')
              AND created_at <= datetime('now', ?)
            """,
            (f"-{STALE_HOURS} hours",),
        )
        conn.commit()

    conn.close()

    return stale
