"""
ChannelFlow AI - Referral Program
====================================

Two separate moments, on purpose:

    1. capture_referral() - called from /start when a brand-new user
       arrives via a `ref_<inviter_id>` deep link. Just records who
       invited whom, status "not verified" (reward_granted=0). No
       reward yet.
    2. grant_reward_if_pending() - called from the admin payment-
       approval handler (services/payment_service.py) whenever a
       user's plan is set via a REAL payment (any purchasable paid
       plan - Beginner or Pro, not just Pro; see
       payment_service.PLAN_PRICES for what's currently purchasable).
       Only then does the referrer get +7 days, and only then does
       this referral flip from "not verified" to "active" in
       get_referral_stats(). This matches the confirmed business rule:
       the reward is for a paying referral, not merely a signup, and
       it doesn't matter which paid plan they chose.

Trial-plan grants (services/plan_service.start_trial, CREATORS) never
call this - only services/payment_service.approve_payment does, so a
free trial can never accidentally trigger a referral reward.

Rewards stack: each distinct referred person who converts adds another
+7 days on top of the referrer's current plan_expiry (not replacing
it), via plan_service.extend_plan().
"""

from database.db import get_connection
from services import plan_service

REFERRAL_REWARD_DAYS = 7
REFERRAL_REWARD_PLAN = "PRO"  # floor plan the referrer is raised to if lower


def build_referral_code(telegram_id) -> str:
    """The inviter's own telegram_id IS the code - simple, unique by
    construction, and traceable without a second lookup table."""

    return f"ref_{telegram_id}"


def parse_referral_code(start_param) -> "int | None":

    if not start_param or not start_param.startswith("ref_"):
        return None

    try:
        return int(start_param[len("ref_"):])
    except ValueError:
        return None


def capture_referral(referrer_id, referred_id):
    """No-ops safely (does not raise) if: the referrer is the same
    person as the referred user, the referrer doesn't exist, or this
    referred_id already has a referral row (UNIQUE constraint - first
    link used wins, silently)."""

    if referrer_id == referred_id:
        return False

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT 1 FROM users WHERE telegram_id=?", (referrer_id,))
    if cur.fetchone() is None:
        conn.close()
        return False

    try:
        cur.execute(
            "INSERT INTO referrals(referrer_id, referred_id) VALUES (?, ?)",
            (referrer_id, referred_id),
        )
        conn.commit()
        captured = True

    except Exception:
        # Already referred by someone else, or some other integrity
        # issue - either way, not this call's job to fix.
        captured = False

    conn.close()

    return captured


def grant_reward_if_pending(referred_id, new_plan):
    """Call this every time a user's plan is set via a REAL payment
    (services/payment_service.py's admin-approval path) - never from a
    trial grant. Fires for ANY paid plan the referred user converts
    to (not just PRO), as long as this referred_id has an unrewarded
    referral row. Everything else is a silent no-op, so callers don't
    need to pre-check anything themselves.

    "Paid plan" here means anything payment_service actually sells -
    delegated to that module's PLAN_PRICES rather than hard-coding the
    list here a second time."""

    from services import payment_service  # local import: payment_service
    # already imports plan_service + referral_service, so a top-level
    # import here would be circular.

    if new_plan not in payment_service.PLAN_PRICES:
        return None

    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT id, referrer_id FROM referrals WHERE referred_id=? AND reward_granted=0",
        (referred_id,),
    )
    row = cur.fetchone()

    if row is None:
        conn.close()
        return None

    cur.execute(
        "UPDATE referrals SET reward_granted=1, rewarded_at=CURRENT_TIMESTAMP WHERE id=?",
        (row["id"],),
    )

    conn.commit()
    conn.close()

    plan_service.extend_plan(row["referrer_id"], REFERRAL_REWARD_PLAN, REFERRAL_REWARD_DAYS)

    return row["referrer_id"]


def get_referral_stats(telegram_id):

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (telegram_id,))
    total = cur.fetchone()[0]

    cur.execute(
        "SELECT COUNT(*) FROM referrals WHERE referrer_id=? AND reward_granted=1",
        (telegram_id,),
    )
    rewarded = cur.fetchone()[0]

    conn.close()

    return {"total_invited": total, "active_referrals": rewarded}
